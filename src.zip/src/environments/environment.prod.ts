export const environment = {
  production: true,
  apiUrl: 'https://timserver.northeurope.cloudapp.azure.com/QalitasWebApi/api' // L'URL de base de l'API en production
};
