export interface Employee {
  id: string;
  fullName: string;
  IsEnabled: boolean;
} 